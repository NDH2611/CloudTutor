const {
  S3Client,
  GetObjectCommand,
} = require("@aws-sdk/client-s3");

const { describeFrame } = require("./geminiVision");

const s3 = new S3Client({
  region: process.env.AWS_REGION || "ap-southeast-1",
});

const bucket = process.env.MEDIA_BUCKET;

// Đọc một frame JPEG từ S3.
async function readFrame(frameKey) {
  const result = await s3.send(
    new GetObjectCommand({
      Bucket: bucket,
      Key: frameKey,
    })
  );

  if (!result.Body) {
    throw new Error("Frame khong co noi dung");
  }

  if (result.ContentLength > 4 * 1024 * 1024) {
    throw new Error("Frame vuot gioi han 4 MB");
  }

  const bytes = await result.Body.transformToByteArray();

  if (bytes.length === 0 || bytes.length > 4 * 1024 * 1024) {
    throw new Error("Kich thuoc frame khong hop le");
  }

  return bytes;
}

exports.handler = async (event) => {
  if (!bucket) {
    throw new Error("Thieu bien moi truong MEDIA_BUCKET");
  }

  // Đây là định dạng event tạm để kiểm thử, chưa phải message SQS.
  const frames = event?.frames;
  const duration = Number(event?.duration_seconds);
  const interval = Number(event?.frame_interval_seconds);

  if (!Array.isArray(frames) || frames.length < 1 || frames.length > 3) {
    throw new Error("Can tu 1 den 3 frame cho lan kiem thu");
  }

  if (!Number.isFinite(duration) || duration <= 0) {
    throw new Error("duration_seconds khong hop le");
  }

  if (!Number.isFinite(interval) || interval <= 0) {
    throw new Error("frame_interval_seconds khong hop le");
  }

  const segments = [];
  const usage = [];

  for (const frame of frames) {
    const key = frame?.key;
    const index = frame?.index;

    if (
      typeof key !== "string" ||
      !key.startsWith("frames/") ||
      !key.toLowerCase().endsWith(".jpg") ||
      key.includes("..") ||
      !Number.isInteger(index) ||
      index < 0
    ) {
      throw new Error("Thong tin frame khong hop le");
    }

    const start = index * interval;
    const end = Math.min(start + interval, duration);

    if (start >= duration) {
      throw new Error("Timestamp frame nam ngoai video");
    }

    console.log("Dang xu ly frame:", key);

    const imageBytes = await readFrame(key);
    const result = await describeFrame(imageBytes);

    segments.push({
      start_time: start,
      end_time: end,
      text: result.text,
      source: "VISION",
      frame_key: key,
    });

    usage.push({
      frame_key: key,
      usage: result.usage,
    });
  }

  return {
    test: "VISION_MULTI_FRAME_TEST",
    source: "VISION",
    segments,
    usage,
    warnings: [
      "AI_GENERATED_VISUAL_DESCRIPTION",
      "VISION_TIMESTAMPS_ARE_SAMPLED",
    ],
  };
};